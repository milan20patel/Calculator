# Calculator-app

## Android, Kotlin

Use Jetpack Compose


<img src="https://github.com/hoductrihcmut123/Calculator-app/assets/76983358/36132bbb-b933-4687-9c10-1e8fc81373d4" width="300">
<img src="https://github.com/hoductrihcmut123/Calculator-app/assets/76983358/40dd0fca-e961-4a21-9ec7-3e756c9e92b6" width="300">
